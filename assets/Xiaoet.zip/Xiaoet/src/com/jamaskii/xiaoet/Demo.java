package com.jamaskii.xiaoet;

import com.jamaskii.xiaoet.intermediator.Product;
import com.jamaskii.xiaoet.intermediator.Resource;
import com.jamaskii.xiaoet.structure.Video;

import java.util.List;

public class Demo {
    public static void main (String[] args){
        String cookie="ko_token=c4e49c02c473263a599c536a41aaefc8;";
        String appId="apppRCekQIr1928";
        List<Product> products=Product.getProducts(cookie,appId);
        for (Product product:products
             ) {
            System.out.println(product.name+"\t"+product.appId+"\t"+product.productId);
            List<Resource> resources=Resource.getResources(cookie,appId,product.productId);
            for (Resource resource:resources
                 ) {
                Video video=Video.parseFromResource(cookie,resource);
                System.out.println("\t"+video.title+"\t"+video.videoUrl+"\t"+video.keyUrl);
            }
        }
    }
}
