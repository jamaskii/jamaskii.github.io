package com.jamaskii.xiaoet.structure;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.jamaskii.xiaoet.intermediator.Resource;
import com.jamaskii.xiaoet.utils.Net;
import com.jamaskii.xiaoet.utils.Response;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Video {
    public String title;
    public String videoUrl;
    public String keyUrl;

    /**
     *
     * @param title
     * @param m3u8
     * @return
     */
    public static Video parseFromM3u8(String title,String m3u8){
        Video video=new Video();
        video.title=title;
        try{
            //读取m3u8文件
            String[] m3u8Lines= Net.get(m3u8).getText().split("\n");

            for (String line:m3u8Lines
                 ) {
                //从m3u8文件中获取秘钥地址
                if(line.indexOf("#EXT-X-KEY")!=-1 && video.keyUrl==null){
                    Pattern pattern=Pattern.compile("URI=\"(.+?)\"");
                    Matcher matcher=pattern.matcher(line);
                    if(matcher.find()){
                        video.keyUrl=matcher.group(1);
                    }
                }
                //从m3u8文件获取加密过的视频文件地址
                else if(line.indexOf("#")==-1 && video.videoUrl==null){
                    String fileName=line.split("\\?")[0];
                    String path=m3u8.split("drm/")[0]+"drm/";
                    video.videoUrl=path+fileName;
                }
                if(video.videoUrl!=null && video.keyUrl!=null){
                    break;
                }
            }

            return video;
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    /**
     *
     * @param cookie
     * @param resource
     * @return
     */
    public static Video parseFromResource(String cookie,Resource resource){
        try{
            //构建获取资源详情的url
            String url="https://"+resource.appId+".h5.xiaoeknow.com/video/base_info";
            //发起请求时发送的数据
            String data="pay_info={\"type\":\"2\",\"product_id\":\""+resource.productId+"\",\"from_multi_course\":\"1\",\"resource_id\":\""+resource.resourceId+"\",\"resource_type\":3,\"app_id\":\""+resource.appId+"\"}";
            //发起请求时的headers
            Map<String,String> headers=new HashMap();
            headers.put("accept","application/json, text/plain, */*");
            headers.put("accept-encoding","deflate, br");
            headers.put("accept-language","zh-CN,zh;q=0.9");
            headers.put("content-type","application/x-www-form-urlencoded");
            headers.put("cookie",cookie);
            headers.put("user-agent","Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.85 Mobile Safari/537.36");

            //发起请求并接收反应
            Response response=Net.post(url,data,headers);

            //解析json
            JSONObject jsonObject= JSON.parseObject(response.getText());

            //视频的m3u8路径是加密的，但视频的音频的url确是暴露的，可以据此获取路径；且m3u8的文件名一般是固定的，这样便可以或得到完整的m3u8路径
            //读取音频的url
            String audioUrl=jsonObject.getJSONObject("data").getJSONObject("bizData").getJSONObject("data").getString("video_audio_url");
            //构建路径
            String[] nodes=audioUrl.split("/");
            String path="";
            for(int i=0;i< (nodes.length-1);i++){
                path+=nodes[i];
                path+="/";
            }
            //将路径和m3u8文件名组合
            String m3u8=path+"drm/v.f230.m3u8";
            return Video.parseFromM3u8(resource.name,m3u8);
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

}
