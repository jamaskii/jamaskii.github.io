package com.jamaskii.xiaoet.structure;

public abstract class VideoTaskListener {
    public void onTaskStatusChanged(VideoTask videoTask,int oldStatus){ }

    public void onVideoDownloadProgressChanged(VideoTask videoTask,String speed, long totalSize, long downloadedSize){}

}
