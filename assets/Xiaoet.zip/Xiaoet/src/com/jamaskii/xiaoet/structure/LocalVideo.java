package com.jamaskii.xiaoet.structure;

import java.util.ArrayList;
import java.util.List;

public class LocalVideo extends Video{
    public String title;
    public String path;

    public static List<LocalVideo> loadLocalVideos(){
        List<LocalVideo> localVideos=new ArrayList<>();
        return localVideos;
    }
}
