package com.jamaskii.xiaoet.structure;

import java.security.MessageDigest;

public class VideoTask {
    public String taskId;
    public Video video;

    private int status=-1;
    private VideoTaskListener videoTaskListener;

    public static final int STEP_INLINE=0;
    public static final int STEP_VIDEO_DOWNLOADING=0;
    public static final int STEP_VIDEO_DOWNLOAD_PAUSED=0;
    public static final int STEP_VIDEO_DOWNLOAD_ERROR=0;
    public static final int STEP_VIDEO_DECRYPTING=0;
    public static final int STEP_DONE=0;

    public int getStatus(){
        return this.status;
    }

    public void setStatus(int newStatus){
        int oldStatus=this.status;
        this.status=newStatus;
        videoTaskListener.onTaskStatusChanged(this,oldStatus);
    }

    public VideoTask(Video video,VideoTaskListener videoTaskListener){
        try{
            this.taskId= new String(MessageDigest.getInstance("md5").digest((System.currentTimeMillis()+"").getBytes()));
            this.video=video;
            this.videoTaskListener=videoTaskListener;
            this.setStatus(VideoTask.STEP_INLINE);
        }catch (Exception e){
            e.printStackTrace();
            System.exit(-1);
        }
    }
}
