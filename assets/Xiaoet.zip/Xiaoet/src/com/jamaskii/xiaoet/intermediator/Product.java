package com.jamaskii.xiaoet.intermediator;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.jamaskii.xiaoet.utils.Net;
import com.jamaskii.xiaoet.utils.Response;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Product {

    public String productId;
    public String appId;
    public String name;

    /**
     *
     * @param cookie 登录后获取到cookie中的ko_token
     * @param appId  店铺的ID
     * @return       返回一个Product列表
     */
    public static List<Product> getProducts(String cookie,String appId){
        List<Product> products=new ArrayList<>();
        try{
            //构建获取已购列表的url
            String url="https://"+appId+".h5.xiaoeknow.com/payRecords";

            //设置headers
            Map<String,String> headers=new HashMap();
            headers.put("accept","application/json, text/plain, */*");
            headers.put("accept-encoding","deflate, br");
            headers.put("accept-language","zh-CN,zh;q=0.9");
            headers.put("content-type","application/x-www-form-urlencoded");
            headers.put("cookie",cookie);
            headers.put("user-agent","Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.85 Mobile Safari/537.36");

            //发起请求并获取回应对象
            Response response=Net.get(url,headers);

            //正则表达式匹配html文档中的base64编码过的已购列表
            Pattern pattern=Pattern.compile("<input id=\"initData\" type=\"hidden\" style=\"display: none\" value=\"(.+?)\">");
            Matcher matcher=pattern.matcher(response.getText());
            matcher.find();
            String base64encoded=matcher.group(1);

            //base64解码
            String jStr= new String(Base64.getDecoder().decode(base64encoded));

            //构建json对象
            JSONObject jsonObject=JSON.parseObject(jStr);
            JSONArray jsonArray=jsonObject.getJSONObject("bizData").getJSONObject("buyDataList").getJSONArray("data");

            //读取每一个产品的信息
            for (Object item:jsonArray.toArray()
                 ) {
                JSONObject jItem=(JSONObject) item;
                Product product=new Product();
                product.name=jItem.getString("purchase_name");//获取产品名
                product.productId=jItem.getString("product_id");//获取产品ID
                product.appId=appId;//标记上店铺ID
                products.add(product);
            }

            return products;
        }catch (Exception e){
            e.printStackTrace();
            return products;//捕捉到任何异常都将返回空列表而不是null
        }
    }
}
