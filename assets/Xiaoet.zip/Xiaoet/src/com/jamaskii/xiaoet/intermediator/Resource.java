package com.jamaskii.xiaoet.intermediator;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.jamaskii.xiaoet.utils.Net;
import com.jamaskii.xiaoet.utils.Response;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Resource {

    public String name;
    public String resourceId;
    public int resourceType=-1;
    public String productId;
    public String appId;

    public static List<Resource> getResources(String cookie,String appId,String productId){
        List<Resource> resources=new ArrayList<>();
        try{
            //设置获取产品内课程的url
            String url="https://"+appId+".h5.xiaoeknow.com/column_more_data_v2/column_more_data";

            //设置headers
            Map<String,String> headers=new HashMap();
            headers.put("accept","application/json, text/plain, */*");
            headers.put("accept-encoding","deflate, br");
            headers.put("accept-language","zh-CN,zh;q=0.9");
            headers.put("content-type","application/x-www-form-urlencoded");
            headers.put("cookie",cookie);
            headers.put("user-agent","Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.85 Mobile Safari/537.36");

            //设置发送的数据
            String data="bizData[page_size]=0&bizData[isDesc]=1&bizData[content_app_id]=&bizData[channel_id]=&bizData[product_id]="+productId+"&bizData[qy_app_id]=";

            //发起请求并获取回应对象
            Response response= Net.post(url,data,headers);

            //构建json对象
            JSONObject jsonObject= JSON.parseObject(response.getText());
            JSONArray jsonArray=jsonObject.getJSONObject("data").getJSONObject("contentData").getJSONArray("contentInfo");

            //读取每一课程的信息
            for (Object item:jsonArray.toArray()
            ) {
                JSONObject jItem=(JSONObject) item;
                Resource resource=new Resource();
                resource.appId=appId;
                resource.productId=productId;
                resource.resourceId=jItem.getString("id");
                resource.name=jItem.getString("resource_name");
                resource.resourceType=jItem.getInteger("resource_type");
                resources.add(resource);
            }
            return resources;
        }catch (Exception e){
            e.printStackTrace();
            return resources;
        }
    }

}
