package com.jamaskii.utils.net;

import com.jamaskii.xiaoet.utils.IOUtils;

import java.io.IOException;
import java.net.*;
import java.util.Map;

public class Net {
    public static Response get(String url){
        try{
            HttpURLConnection connection=(HttpURLConnection) new URL(url).openConnection();
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(15000);
            connection.connect();
            Response response=new Response();
            response.data= IOUtils.readBytes(connection.getInputStream());
            //response.text=new String(response.data);
            response.cookies=connection.getHeaderField("Set-Cookie");
            return response;
        }catch (MalformedURLException e){
            return null;
        }catch (IOException e){
            return null;
        }
    }

    public static Response get(String url, Map<String,String> headers){
        try{
            HttpURLConnection connection=(HttpURLConnection) new URL(url).openConnection();
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(15000);

            Object[] keys=headers.keySet().toArray();
            for (Object key:keys
                 ) {
                connection.setRequestProperty((String)key, (String)headers.get(key));
            }

            connection.connect();
            Response response=new Response();
            response.data= IOUtils.readBytes(connection.getInputStream());
            response.cookies=connection.getHeaderField("Set-Cookie");
            return response;
        }catch (MalformedURLException e){
            return null;
        }catch (IOException e){
            return null;
        }
    }

    public static Response post(String url, byte[] data){
        try{
            HttpURLConnection connection=(HttpURLConnection) new URL(url).openConnection();
            connection.setDoOutput(true);
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(15000);
            connection.connect();

            connection.getOutputStream().write(data);

            Response response=new Response();
            response.data= IOUtils.readBytes(connection.getInputStream());
            //response.text=new String(response.data);
            response.cookies=connection.getHeaderField("Set-Cookie");
            return response;
        }catch (MalformedURLException e){
            return null;
        }catch (IOException e){
            return null;
        }
    }

    public static Response post(String url, String data){
        try{
            HttpURLConnection connection=(HttpURLConnection) new URL(url).openConnection();
            connection.setDoOutput(true);
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(15000);
            connection.connect();

            connection.getOutputStream().write(data.getBytes("utf-8"));

            Response response=new Response();
            response.data= IOUtils.readBytes(connection.getInputStream());
            //response.text=new String(response.data);
            response.cookies=connection.getHeaderField("Set-Cookie");
            return response;
        }catch (MalformedURLException e){
            return null;
        }catch (IOException e){
            return null;
        }
    }

    public static Response post(String url, String data, String encoding){
        try{
            HttpURLConnection connection=(HttpURLConnection) new URL(url).openConnection();
            connection.setDoOutput(true);
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(15000);
            connection.setRequestMethod("POST");

            connection.connect();

            connection.getOutputStream().write(data.getBytes(encoding));

            Response response=new Response();
            response.data= IOUtils.readBytes(connection.getInputStream());
            //response.text=new String(response.data);
            response.cookies=connection.getHeaderField("Set-Cookie");
            return response;
        }catch (MalformedURLException e){
            return null;
        }catch (IOException e){
            return null;
        }
    }

    public static Response post(String url, byte[] data, Map<String,String> headers){
        try{
            HttpURLConnection connection=(HttpURLConnection) new URL(url).openConnection();
            connection.setDoOutput(true);
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(15000);
            connection.setRequestMethod("POST");
            Object[] keys=headers.keySet().toArray();
            for (Object key:keys
            ) {
                connection.setRequestProperty((String)key, (String)headers.get(key));
            }
            connection.connect();
            connection.getOutputStream().write(data);

            Response response=new Response();
            response.data= IOUtils.readBytes(connection.getInputStream());
            //response.text=new String(response.data);
            response.cookies=connection.getHeaderField("Set-Cookie");
            return response;
        }catch (MalformedURLException e){
            return null;
        }catch (IOException e){
            return null;
        }
    }

    public static Response post(String url, String data, Map<String,String> headers){
        try{
            HttpURLConnection connection=(HttpURLConnection) new URL(url).openConnection();
            connection.setDoOutput(true);
            connection.setRequestMethod("POST");
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(15000);

            Object[] keys=headers.keySet().toArray();
            for (Object key:keys
            ) {
                connection.setRequestProperty((String)key, (String)headers.get(key));
            }
            connection.connect();
            connection.getOutputStream().write(data.getBytes("utf-8"));

            Response response=new Response();
            response.data=IOUtils.readBytes(connection.getInputStream());
            response.cookies=connection.getHeaderField("Set-Cookie");
            return response;
        }
        catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public static Response post(String url, String data, Map<String,String> headers, String encoding){
        try{
            HttpURLConnection connection=(HttpURLConnection) new URL(url).openConnection();
            connection.setDoOutput(true);
            connection.setConnectTimeout(5000);
            connection.setReadTimeout(15000);
            connection.setRequestMethod("POST");
            Object[] keys=headers.keySet().toArray();
            for (Object key:keys
            ) {
                connection.setRequestProperty((String)key, (String)headers.get(key));
            }
            connection.connect();
            connection.getOutputStream().write(data.getBytes(encoding));

            Response response=new Response();
            response.data= IOUtils.readBytes(connection.getInputStream());
            //response.text=new String(response.data);
            response.cookies=connection.getHeaderField("Set-Cookie");
            return response;
        }catch (MalformedURLException e){
            return null;
        }catch (IOException e){
            return null;
        }
    }

}
